class Person():
    def __init__(self, cipher):
        self.cipher = cipher

    def set_key(self, key):
        self.key = key

    def get_key(self):
        return self.keys
